package com.example.volamtabs;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** 8 tab, mỗi tab là 1 WebView chạy game. Không đăng nhập key, không ghi phím. */
public class MainActivity extends Activity {
    static final String GAME_URL = "https://volamidle.pages.dev";
    static final int TABS = 8;

    private final WebView[] webs = new WebView[TABS];
    private final Button[] buttons = new Button[TABS];
    private FrameLayout content;
    private int current = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < TABS; i++) {
            final int idx = i;
            Button t = new Button(this);
            t.setText(String.valueOf(i + 1));
            t.setAllCaps(false);
            t.setPadding(0, 0, 0, 0);
            t.setOnClickListener(v -> select(idx));
            bar.addView(t, new LinearLayout.LayoutParams(0, dp(44), 1f));
            buttons[i] = t;
        }
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        CookieManager.getInstance().setAcceptCookie(true);
        select(0);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private WebView create() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient());
        w.loadUrl(GAME_URL);
        return w;
    }

    private void select(int idx) {
        current = idx;
        if (webs[idx] == null) {            // tạo tab khi bấm lần đầu
            webs[idx] = create();
            content.addView(webs[idx], new FrameLayout.LayoutParams(-1, -1));
        }
        for (int i = 0; i < TABS; i++) {     // tab nền vẫn chạy, chỉ ẩn đi
            if (webs[i] != null) webs[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            buttons[i].setTextColor(i == idx ? Color.YELLOW : Color.WHITE);
            buttons[i].setBackgroundColor(i == idx ? 0xFF8B0000 : 0xFF333333);
            buttons[i].setGravity(Gravity.CENTER);
        }
    }

    @Override public void onBackPressed() {
        WebView w = webs[current];
        if (w != null && w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
